package com.example.eva1_2_widgets;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txtMensos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtMensos = findViewById(R.id.txtVWMensos);
        txtMensos.setText("Hola mundo desde Android Studio");
        txtMensos.setText(R.string.mi_cadena);
    }
}
