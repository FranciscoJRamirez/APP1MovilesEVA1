package com.example.eva1_5_radio_group;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
    RadioGroup radioGroup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        radioGroup = findViewById(R.id.idGroupPostres);
        radioGroup.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        String sMensaje;
        if (i == R.id.radioButton){
            sMensaje = "Pastel";
        } else if (i == R.id.radioButton2){
            sMensaje = "Helado";
        }else if (i == R.id.radioButton3){
            sMensaje = "Chocolate";
        }else {
            sMensaje = "Pay";
        }
        Toast.makeText(this, sMensaje, Toast.LENGTH_LONG).show();

    }
}
