package com.example.eva1_4_eventos;

import android.content.Context;
import android.view.View;
import android.widget.Toast;

public class MiEventoClick implements View.OnClickListener {
    Context con;
    @Override
    public void onClick(View view) {
        Toast.makeText(con , "hola desde otra clase", Toast.LENGTH_LONG).show();
    }
    public void setCon(Context con){
        this.con=con;
    }
}
