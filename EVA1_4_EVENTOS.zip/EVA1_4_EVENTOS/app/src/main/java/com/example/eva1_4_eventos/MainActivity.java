package com.example.eva1_4_eventos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button btnPortInt, btnPorClaseAn, btnClaseExt;

    @Override
    public void onClick(View view) {
        Toast.makeText( this, "Evento por listener", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnPortInt = findViewById(R.id.btnPorInt);
        btnPortInt.setOnClickListener(this);

        btnPorClaseAn = findViewById(R.id.btnPorClaseAn);
        btnPorClaseAn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText( getApplicationContext(), "Hola mundo por clase anonima", Toast.LENGTH_LONG).show();
            }
        });

        btnClaseExt = findViewById(R.id.btnClaseExt);
        MiEventoClick meclick = new MiEventoClick();
        meclick.setCon(this);
        btnClaseExt.setOnClickListener(meclick);
    }
    public void miClick(View v){
        Toast.makeText( this, "Hola mundo!", Toast.LENGTH_LONG).show();
    }
}
