package com.example.eva1_10_1_restaurantes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    Restaurantes [] restaurantes={
      new Restaurantes(),
            new Restaurantes(R.drawable.hamburger, "Hamburguesas el combi","Las mas ricas del sur"),
            new Restaurantes(R.drawable.ensalada, "Ensaladas caseras 'Ivonne'", "mas saludable que nunca"),
            new Restaurantes(R.drawable.tacos, "Tacos el pelado", "los mejores tacos del estado"),
            new Restaurantes(R.drawable.hotdogs, "HotDogs el puerco", "quedaras como puerco")
    };
    ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lista = findViewById(R.id.list1);
        lista.setAdapter(new RestAdapter(this, R.layout.layout_rest, restaurantes));
        lista.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(this, restaurantes[i].getDesc(), Toast.LENGTH_SHORT).show();
    }
}
