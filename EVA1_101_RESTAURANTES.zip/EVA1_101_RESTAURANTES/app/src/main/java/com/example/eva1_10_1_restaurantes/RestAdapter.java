package com.example.eva1_10_1_restaurantes;

import android.widget.ArrayAdapter;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.zip.Inflater;

public class RestAdapter extends ArrayAdapter<Restaurantes> {
    Context context;
    int resource;
    Restaurantes [] restaurantes;


    @Override
    public View getView(int position,  View convertView, ViewGroup parent) {

        ImageView imgRest;
        TextView txtName, txtDesc;
        if (convertView == null){
            LayoutInflater inflater= ((Activity)context).getLayoutInflater();
            convertView=inflater.inflate(resource, parent, false);
        }
        imgRest=convertView.findViewById(R.id.imageView5);
        txtName=convertView.findViewById(R.id.txtTitle);
        txtDesc=convertView.findViewById(R.id.txtDesc);

        imgRest.setImageResource(restaurantes[position].getImage());
        txtName.setText(restaurantes[position].getName());
        txtDesc.setText(restaurantes[position].getDesc());

        return convertView;

    }

    public RestAdapter(Context context, int resource, Restaurantes[] objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.restaurantes=objects;

    }
}
