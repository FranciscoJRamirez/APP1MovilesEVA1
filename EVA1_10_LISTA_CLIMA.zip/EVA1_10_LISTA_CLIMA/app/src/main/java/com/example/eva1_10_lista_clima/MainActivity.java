package com.example.eva1_10_lista_clima;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements ListView.OnItemClickListener{
    Clima [] cCiudades ={
      new Clima(),
            new Clima(R.drawable.atmospher, "Aldama", 25, "Chido"),
            new Clima(R.drawable.cloudy, "Camargo", 25, "Chido"),
            new Clima(R.drawable.light_rain, "Parral", 25, "Chido"),
            new Clima(R.drawable.rainy, "Madera", 25, "Chido"),
            new Clima(R.drawable.snow, "Creel", 25, "Chido"),
            new Clima(R.drawable.sunny, "Jimenez", 25, "Chido"),
            new Clima(R.drawable.thunderstorm, "Juarez", 25, "Chido"),
            new Clima(R.drawable.tornado, "Hidalgo del parral", 25, "Chido")

    };
    ListView listaClima;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaClima = findViewById(R.id.listClima);
        listaClima.setAdapter(new CilmaAdapter(this, R.layout.layout_clima, cCiudades));
        listaClima.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(this, cCiudades[i].getCiudad(), Toast.LENGTH_SHORT).show();
    }
}
