package com.example.eva1_10_lista_clima;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CilmaAdapter extends ArrayAdapter<Clima> {

    Context context;
    int resource;
    Clima[] cCiudades;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imgClima;
        TextView txtciudad, txtTemp, txtClima;

        //CONVERTVIEW ES EL LAYOUT QUE REPRESENTA UNA FILA EN LA LISTA
        if (convertView == null){
            //CREAR NUESTRO LAYOUT
            //INFLATER
            LayoutInflater linflator = ((Activity)context).getLayoutInflater();
            convertView = linflator.inflate(resource,parent,false);
        }
        imgClima = convertView.findViewById(R.id.image);
        txtciudad = convertView.findViewById(R.id.txtciudad);
        txtTemp = convertView.findViewById(R.id.txttemp);
        txtClima = convertView.findViewById(R.id.txtclima);

        imgClima.setImageResource(cCiudades[position].getImagen());
        txtciudad.setText(cCiudades[position].getCiudad());
        txtTemp.setText(cCiudades[position].getTemp() + "C");
        txtClima.setText(cCiudades[position].getClima());



        return convertView;
    }

    public CilmaAdapter(Context context, int resource, Clima[] objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.cCiudades = objects;
    }
}
